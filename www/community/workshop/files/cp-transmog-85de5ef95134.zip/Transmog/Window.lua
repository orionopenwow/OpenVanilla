--[[
    Window.lua  (Open Vanilla / Transmog)
    The Transmogrifier window, laid out as retail's since Midnight:

      left    the saved outfits ("Equipped gear" first). Click one to wear it (free, anywhere)
              and edit it; right-click to rename it or give it an icon. A locked row at the end
              unlocks the next outfit slot for its price.
      middle  your character dressed as the outfit you're editing, the transmog slots around
              it. Click a slot to pick its look on the right; right-click a changed slot to undo
              that change. A changed slot glows purple; a hidden one shows a red cross.
      right   tabs: Items (the looks you've collected for the slot, as models, 12 a page, with
              Hide for the hideable slots and Illusions for weapons), Sets (item sets: how much
              of each you've collected, preview, use), Custom Sets (looks saved for later or to
              share as a chat link) and Situations (when this outfit puts itself on).
      bottom  the cost of the changes and Apply. Hiding a slot and going back to the equipped
              item are free; your first saved outfit is free.

    Talk to a Transmogrifier (Lyriel Threadweave in Alliance towns, Morga Silkhand in Horde ones)
    to open it; /transmog opens it anywhere to look and to switch outfits.
]]--

local W = WenillaCore
local UI = W.UI
local T = Transmog

local strfind, strlower, format = string.find, string.lower, string.format
local getn, tinsert = table.getn, table.insert
local floor = math.floor

local WIN_W, WIN_H = 940, 600
local LEFT_W, MID_W = 196, 336
local MID_X = LEFT_W + 10
local RIGHT_X = MID_X + MID_W + 10
local RIGHT_W = 906 - RIGHT_X
local CELL_W, CELL_H, COLS, ROWS = 84, 104, 4, 3
local PER_PAGE = COLS * ROWS
local PURPLE = { 0.72, 0.4, 1 }
local NPCS = { ["Lyriel Threadweave"] = true, ["Morga Silkhand"] = true }
T.NPCS = NPCS

T.view = nil            -- the outfit being edited
T.pending = {}          -- slot -> { look, ill } not saved yet
T.slot = 0              -- the slot whose looks the Items tab lists
T.page = 1
T.mode = "items"        -- items | illusions
T.search = ""
T.cost = 0
T.atNpc = false

local win, model, slotButtons, list, tabs, pages, cells, pageText, costMoney, costNote, applyBtn, resetBtn
local header, countText, countText2, searchBox, illBtn, statusText, viewName, situChecks

-- -- helpers -------------------------------------------------------------------------------

local function equipped(slot)
    local link = GetInventoryItemLink and GetInventoryItemLink("player", slot + 1)
    if not link then return nil end
    local _, _, id = strfind(link, "item:(%d+)")
    return tonumber(id)
end

local function saved(slot)
    local o = T.view and T.looks[T.view]
    return o and o[slot] or nil
end

-- The look a slot shows in the window: pending, else saved, else the equipped item (look 0).
local function effective(slot)
    local p = T.pending[slot]
    if p then return p.look or 0, p.ill or 0, true end
    local s = saved(slot)
    if s then return s.look or 0, s.ill or 0, false end
    return 0, 0, false
end
T.Effective = effective

local function changes()
    local out = {}
    for slot, p in pairs(T.pending) do
        local s = saved(slot) or { look = 0, ill = 0 }
        if (p.look or 0) ~= (s.look or 0) or (p.ill or 0) ~= (s.ill or 0) then out[slot] = p end
    end
    return out
end
T.Changes = changes

local function hasChanges()
    for _ in pairs(changes()) do return true end
    return false
end

local function slotTexture(slot)
    local info = T.SLOT_BY[slot]
    local _, tex = GetInventorySlotInfo(info.name)
    return tex
end

-- -- preview -------------------------------------------------------------------------------

function T:Dress(m, looks)
    if not m then return end
    m:SetUnit("player")
    m:Undress()
    for _, s in ipairs(T.SLOTS) do
        local look
        if looks then
            local l = looks[s.slot]
            look = l and l.look or 0
        else
            look = effective(s.slot)
        end
        if look and look > 0 then
            m:TryOn(look)
        elseif look ~= -1 then
            local real = equipped(s.slot)
            if real then m:TryOn(real) end
        end
    end
end

-- -- the cost ------------------------------------------------------------------------------

local costDue = 0
local function askCost()
    costDue = 0.3
end

local ticker = CreateFrame("Frame", "Transmog_CostTicker")
ticker:SetScript("OnUpdate", function()
    if costDue <= 0 then return end
    costDue = costDue - (arg1 or 0)
    if costDue > 0 then return end
    if T.view and T.view > 0 and hasChanges() then
        T:Send("cost " .. T.view .. " " .. T.FormatLooks(changes(), ","))
    else
        T.cost = 0
        if win then T:RefreshBottom() end
    end
end)

function T:RefreshBottom()
    if not win then return end
    local any = hasChanges()
    if not any then
        costMoney:SetText("|cff9a9aa6No changes|r")
    elseif T.firstFree or (T.cost or 0) == 0 then
        costMoney:SetText("Cost: |cff40ff40Free|r")
    else
        local enough = not GetMoney or GetMoney() >= (T.cost or 0)
        costMoney:SetText("Cost: " .. (enough and "" or "|cffff4040") .. T.CoinText(T.cost) .. (enough and "" or "|r"))
    end
    if not T.view or T.view == 0 then
        costNote:SetText("Pick or unlock an outfit to save looks to it.")
    elseif any and T.firstFree then
        costNote:SetText("|cff40ff40Free: your first saved outfit.|r")
    elseif any and not T.atNpc then
        costNote:SetText("Saving needs a Transmogrifier nearby.")
    else
        costNote:SetText("")
    end
    if any and T.view and T.view > 0 then applyBtn:Enable() else applyBtn:Disable() end
    if any then resetBtn:Enable() else resetBtn:Disable() end
end

-- -- slots ---------------------------------------------------------------------------------

local function paintSlot(b)
    local slot = b.slot
    local look, ill, pending = effective(slot)
    local tex
    if look and look > 0 then
        local _, _, t = T.ItemInfo(look)
        tex = t
    elseif look == 0 then
        tex = GetInventoryItemTexture and GetInventoryItemTexture("player", slot + 1)
    end
    b.icon:SetTexture(tex or slotTexture(slot))
    if tex then b.icon:SetVertexColor(1, 1, 1) else b.icon:SetVertexColor(0.6, 0.6, 0.6) end
    if look == -1 then b.hidden:Show() else b.hidden:Hide() end
    if pending and changes()[slot] then b.glow:Show() else b.glow:Hide() end
    if T.slot == slot then b.sel:Show() else b.sel:Hide() end
    if ill and ill > 0 then b.ill:Show() else b.ill:Hide() end
end

local function makeSlot(parent, info)
    local b = CreateFrame("Button", "TransmogSlot" .. info.name, parent)
    b:SetWidth(38)
    b:SetHeight(38)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b.slot = info.slot
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture("Interface\\Buttons\\UI-EmptySlot-Disabled")
    bg:SetPoint("CENTER", b, "CENTER", 0, 0)
    bg:SetWidth(62)
    bg:SetHeight(62)
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetAllPoints(b)
    b.hidden = b:CreateTexture(nil, "OVERLAY")
    b.hidden:SetTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
    b.hidden:SetPoint("CENTER", b, "CENTER", 0, 0)
    b.hidden:SetWidth(26)
    b.hidden:SetHeight(26)
    b.hidden:Hide()
    b.glow = b:CreateTexture(nil, "OVERLAY")
    b.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    b.glow:SetBlendMode("ADD")
    b.glow:SetVertexColor(PURPLE[1], PURPLE[2], PURPLE[3])
    b.glow:SetPoint("CENTER", b, "CENTER", 0, 0)
    b.glow:SetWidth(70)
    b.glow:SetHeight(70)
    b.glow:Hide()
    b.sel = b:CreateTexture(nil, "OVERLAY")
    b.sel:SetTexture("Interface\\Buttons\\CheckButtonHilight")
    b.sel:SetBlendMode("ADD")
    b.sel:SetAllPoints(b)
    b.sel:Hide()
    b.ill = b:CreateTexture(nil, "OVERLAY")
    b.ill:SetTexture("Interface\\Icons\\Spell_Holy_GreaterHeal")
    b.ill:SetWidth(14)
    b.ill:SetHeight(14)
    b.ill:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 2, -2)
    b.ill:Hide()
    b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")
    b:SetScript("OnClick", function()
        if arg1 == "RightButton" then
            T.pending[this.slot] = nil
            T.preview = nil
            T:Refresh()
            return
        end
        T:SelectSlot(this.slot)
    end)
    b:SetScript("OnEnter", function()
        GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
        local look = effective(this.slot)
        GameTooltip:AddLine(info.label, 1, 0.82, 0)
        if look == -1 then
            GameTooltip:AddLine("Hidden", 0.8, 0.8, 0.8)
        elseif look and look > 0 then
            GameTooltip:AddLine(T.ItemLink(look), 1, 1, 1)
        else
            local real = equipped(this.slot)
            GameTooltip:AddLine(real and ("Equipped: " .. T.ItemLink(real)) or "Nothing equipped", 0.8, 0.8, 0.8)
        end
        if changes()[this.slot] then GameTooltip:AddLine("Changed. Right-click to undo.", PURPLE[1], PURPLE[2], PURPLE[3]) end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return b
end

function T:SelectSlot(slot)
    T.preview = nil
    T.slot = slot
    T.page = 1
    if not T.SLOT_BY[slot].weapon then T.mode = "items" end
    if not T.col[slot] then T:Send("col " .. slot) end
    T:Refresh()
end

-- -- the Items grid ------------------------------------------------------------------------

local SLOT_VIEW = {     -- model framing per slot: zoom toward the camera, raise or lower
    [0] = { 1.6, -0.55 }, [2] = { 1.2, -0.4 }, [14] = { 0.5, 0 }, [4] = { 0.9, -0.25 }, [3] = { 0.9, -0.25 },
    [18] = { 0.9, -0.25 }, [8] = { 1.1, 0 }, [9] = { 1.1, 0.05 }, [5] = { 1.2, 0 }, [6] = { 0.8, 0.3 },
    [7] = { 1.2, 0.6 }, [15] = { 0.4, 0 }, [16] = { 0.4, 0 }, [17] = { 0.4, 0 },
}

local function cellEntries()
    local out = {}
    local info = T.SLOT_BY[T.slot]
    if T.mode == "illusions" then
        tinsert(out, { kind = "noill" })
        for _, i in ipairs(T.ills or {}) do tinsert(out, { kind = "ill", enchant = i.enchant, name = i.name }) end
        return out
    end
    if info.hide then tinsert(out, { kind = "hide" }) end
    local seen = {}
    local q = strlower(T.search or "")
    for _, c in ipairs(T.col[T.slot] or {}) do
        -- one cell per appearance, as retail groups its sources
        if not seen[c.display] then
            local name = T.ItemInfo(c.item)
            if q == "" or (name and strfind(strlower(name), q, 1, true)) then
                seen[c.display] = c
                tinsert(out, { kind = "look", item = c.item, display = c.display, ok = c.ok })
            end
        elseif c.ok and not seen[c.display].ok then
            seen[c.display].ok = true
        end
    end
    return out
end
T.CellEntries = cellEntries

local function paintCell(cell, e)
    cell.entry = e
    local look, ill = effective(T.slot)
    cell.model:Hide()
    cell.icon:Hide()
    cell.name:SetText("")
    cell.sel:Hide()
    cell.lock:Hide()
    if not e then cell:Hide() return end
    cell:Show()
    local useIcons = W:Setting(T.ID, "icons", false)
    if e.kind == "hide" then
        cell.icon:SetTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
        cell.icon:Show()
        cell.name:SetText("Hidden")
        if look == -1 then cell.sel:Show() end
    elseif e.kind == "noill" then
        cell.icon:SetTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
        cell.icon:Show()
        cell.name:SetText("No illusion")
        if (ill or 0) == 0 then cell.sel:Show() end
    elseif e.kind == "ill" then
        cell.icon:SetTexture("Interface\\Icons\\INV_Enchant_EssenceMagicLarge")
        cell.icon:Show()
        cell.name:SetText(e.name ~= "" and e.name or ("Illusion " .. e.enchant))
        if ill == e.enchant then cell.sel:Show() end
    else
        local name, _, tex = T.ItemInfo(e.item)
        if useIcons then
            cell.icon:SetTexture(tex or "Interface\\Icons\\INV_Misc_QuestionMark")
            cell.icon:Show()
        else
            local v = SLOT_VIEW[T.slot] or { 0.8, 0 }
            cell.model:Show()
            cell.model:SetUnit("player")
            cell.model:Undress()
            cell.model:TryOn(e.item)
            if cell.model.SetPosition then cell.model:SetPosition(v[1], 0, v[2]) end
        end
        cell.name:SetText(name or "")
        if look == e.item or (look and look > 0 and T.known[look] == e.display) then cell.sel:Show() end
        if not e.ok then cell.lock:Show() end
    end
end

local function cellClick(cell)
    local e = cell.entry
    if not e then return end
    T.preview = nil
    local p = T.pending[T.slot] or {}
    local look, ill = effective(T.slot)
    if e.kind == "hide" then
        T.pending[T.slot] = { look = -1, ill = 0 }
    elseif e.kind == "noill" then
        T.pending[T.slot] = { look = look, ill = 0 }
    elseif e.kind == "ill" then
        T.pending[T.slot] = { look = look, ill = e.enchant }
    else
        if not e.ok then T.Say("|cffff4040" .. T.Reason("class") .. "|r") return end
        T.pending[T.slot] = { look = e.item, ill = ill }
    end
    T:Refresh()
end

local function cellTip(cell)
    local e = cell.entry
    if not e then return end
    GameTooltip:SetOwner(cell, "ANCHOR_RIGHT")
    if e.kind == "look" then
        GameTooltip:SetHyperlink("item:" .. e.item .. ":0:0:0")
        local others = 0
        for _, c in ipairs(T.col[T.slot] or {}) do if c.display == e.display and c.item ~= e.item then others = others + 1 end end
        if others > 0 then GameTooltip:AddLine("Also collected from " .. others .. " other item" .. (others > 1 and "s" or ""), 0.53, 0.53, 0.93) end
        if not e.ok then GameTooltip:AddLine("Your class can't use this appearance.", 1, 0.25, 0.25) end
    elseif e.kind == "hide" then
        GameTooltip:AddLine("Hidden " .. T.SLOT_BY[T.slot].label, 1, 1, 1)
        GameTooltip:AddLine("Free.", 0.8, 0.8, 0.8)
    else
        GameTooltip:AddLine(cell.name:GetText() or "", 1, 1, 1)
    end
    GameTooltip:Show()
end

-- -- outfits list --------------------------------------------------------------------------

local function outfitItems()
    local items = { { id = 0, name = "Equipped gear" } }
    for id = 1, T.unlocked do
        local o = T.outfits[id]
        tinsert(items, o or { id = id, name = "Outfit " .. id, icon = 0, situ = 0 })
    end
    if T.unlocked < T.max then tinsert(items, { id = -1, locked = true }) end
    return items
end

function T:ViewOutfit(id)
    T.preview = nil
    if T.view ~= id then T.pending = {} end
    T.view = id
    if id and id > 0 and not T.looks[id] then T:Send("outfit " .. id) end
    T:Refresh()
end

local function outfitMenu(id)
    local o = T.outfits[id]
    if not o then return end
    UI.Menu(win, {
        { text = o.name, title = true },
        { text = "Wear it", func = function() T:UseOutfit(id); T:ViewOutfit(id) end },
        { text = "Rename", func = function()
            UI.Prompt({ title = "Rename outfit", default = o.name, maxLetters = 24, accept = "Rename",
                        onAccept = function(text) T:Send("name " .. id .. " " .. text) end })
        end },
        { text = "Use the chest look as its icon", func = function()
            local look = (T.looks[id] or {})[4]
            local item = (look and look.look and look.look > 0) and look.look or equipped(4)
            if item then T:Send("icon " .. id .. " " .. item) end
        end },
        { text = "Situations", func = function() T:ViewOutfit(id); T:SelectTab("situations") end },
    })
end

-- -- tabs: Sets, Custom Sets, Situations ----------------------------------------------------

local setList, csetList, csetSel
local SITU = {
    { "Location", { { 1, "Resting" }, { 2, "World" }, { 4, "Dungeons" }, { 8, "Raids" }, { 16, "Battlegrounds" } } },
    { "Movement", { { 256, "On foot" }, { 512, "Swimming" }, { 1024, "Mounted" } } },
    { "Time of day", { { 4096, "Morning" }, { 8192, "Midday" }, { 16384, "Evening" }, { 32768, "Night" } } },
    { "Weather", { { 65536, "Clear" }, { 131072, "Rain" }, { 262144, "Snow" }, { 524288, "Sandstorm" } } },
    { "Specialization", { { 1048576, "Spec 1" }, { 2097152, "Spec 2" } } },
}
T.SITU = SITU

local function slotOfEquipLoc(loc)
    local map = {
        INVTYPE_HEAD = 0, INVTYPE_SHOULDER = 2, INVTYPE_CLOAK = 14, INVTYPE_CHEST = 4, INVTYPE_ROBE = 4,
        INVTYPE_BODY = 3, INVTYPE_TABARD = 18, INVTYPE_WRIST = 8, INVTYPE_HAND = 9, INVTYPE_WAIST = 5,
        INVTYPE_LEGS = 6, INVTYPE_FEET = 7, INVTYPE_WEAPON = 15, INVTYPE_2HWEAPON = 15, INVTYPE_WEAPONMAINHAND = 15,
        INVTYPE_WEAPONOFFHAND = 16, INVTYPE_SHIELD = 16, INVTYPE_HOLDABLE = 16, INVTYPE_RANGED = 17,
        INVTYPE_RANGEDRIGHT = 17, INVTYPE_THROWN = 17,
    }
    return map[loc or ""]
end
T.SlotOfEquipLoc = slotOfEquipLoc

function T:UseSet(set)
    T.preview = nil
    for _, item in ipairs(set.items) do
        if T.known[item] then
            local _, _, _, _, loc = T.ItemInfo(item)
            local slot = slotOfEquipLoc(loc)
            if slot then T.pending[slot] = { look = item, ill = (T.pending[slot] or {}).ill or 0 } end
        end
    end
    T:Refresh()
end

-- Looks for a custom set / link: every slot not showing the equipped item.
function T:CurrentLooks()
    local out = {}
    for _, s in ipairs(T.SLOTS) do
        local look, ill = effective(s.slot)
        if (look and look ~= 0) or (ill and ill > 0) then out[s.slot] = { look = look, ill = ill } end
    end
    return out
end

function T:PreviewLooks(looks, title)
    T:Build()
    win:Show()
    T.pending = {}
    for slot, l in pairs(looks or {}) do T.pending[slot] = { look = l.look, ill = l.ill } end
    T.preview = nil
    T:SelectTab("items")
    T:Refresh()
    if title then statusText:SetText(title .. ": not yours to save until you've collected its looks.") end
end

-- -- build ---------------------------------------------------------------------------------

function T:SelectTab(key, fromTabs)
    T.tab = key
    for k, p in pairs(pages) do if k == key then p:Show() else p:Hide() end end
    if not fromTabs and tabs and tabs.Select then tabs:Select(key) end
    if key == "sets" and not T.sets then T:Send("sets") end
    if key == "csets" and not T.csets then T:Send("cset list") end
    T:Refresh()
end

function T:Build()
    if win then return win end
    win = UI.ClassicFrame("TransmogFrame", {
        width = WIN_W, height = WIN_H, title = "Transmogrifier", portrait = T.ICON,
        onClose = function() win:Hide() end,
    })
    win:Hide()
    T.win = win
    if UISpecialFrames then tinsert(UISpecialFrames, "TransmogFrame") end
    win:SetScript("OnHide", function() T.atNpc = false; T.pending = {} end)
    local body = win.body

    -- left: outfits
    local lh = UI.Label(body, 12, UI.ACCENT)
    lh:SetPoint("TOPLEFT", body, "TOPLEFT", 2, 0)
    lh:SetText("Outfits")
    countText = UI.Label(body, 10, UI.MUTED)
    countText:SetPoint("TOPRIGHT", body, "TOPLEFT", LEFT_W, -2)
    list = UI.ScrollList(body, {
        width = LEFT_W, height = 432, rowHeight = 36,
        build = function(row)
            row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            row.bg = row:CreateTexture(nil, "BACKGROUND")
            row.bg:SetAllPoints(row)
            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetWidth(30)
            row.icon:SetHeight(30)
            row.icon:SetPoint("LEFT", row, "LEFT", 3, 0)
            row.name = UI.Label(row, 11)
            row.name:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 6, -2)
            row.name:SetPoint("RIGHT", row, "RIGHT", -4, 0)
            row.name:SetJustifyH("LEFT")
            row.sub = UI.Label(row, 9, UI.MUTED)
            row.sub:SetPoint("BOTTOMLEFT", row.icon, "BOTTOMRIGHT", 6, 2)
            row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
            row:SetScript("OnClick", function()
                local it = this.item
                if not it then return end
                if it.locked then
                    UI.Menu(this, {
                        { text = "Unlock outfit slot " .. (T.unlocked + 1), title = true },
                        { text = "Unlock for " .. T.CoinText(T.nextCost), func = function() T:Send("unlock") end },
                    })
                    return
                end
                if arg1 == "RightButton" and it.id > 0 then outfitMenu(it.id) return end
                T:UseOutfit(it.id)
                T:ViewOutfit(it.id)
            end)
        end,
        update = function(row, it)
            if it.locked then
                row.icon:SetTexture("Interface\\Icons\\INV_Misc_Key_03")
                row.name:SetText("|cff9d9d9dLocked outfit slot|r")
                row.sub:SetText("Unlock: " .. T.CoinText(T.nextCost))
                row.bg:SetTexture(0, 0, 0, 0)
                return
            end
            local tex
            if it.id == 0 then tex = "Interface\\Icons\\INV_Chest_Chain"
            elseif it.icon and it.icon > 0 then local _, _, t = T.ItemInfo(it.icon); tex = t end
            row.icon:SetTexture(tex or "Interface\\Icons\\INV_Chest_Cloth_17")
            row.name:SetText(it.name)
            local sub = ""
            if it.id == T.active then sub = "|cff40ff40Wearing|r" end
            if it.situ and it.situ > 0 then sub = sub .. (sub ~= "" and "  " or "") .. "|cffc080ffAuto|r" end
            row.sub:SetText(sub)
            if it.id == T.view then row.bg:SetTexture(PURPLE[1], PURPLE[2], PURPLE[3], 0.18) else row.bg:SetTexture(0, 0, 0, 0) end
        end,
    })
    list:SetPoint("TOPLEFT", body, "TOPLEFT", 0, -20)

    -- middle: the model and the slots
    local mid = CreateFrame("Frame", nil, body)
    mid:SetPoint("TOPLEFT", body, "TOPLEFT", MID_X, 0)
    mid:SetWidth(MID_W)
    mid:SetHeight(466)
    UI.Skin(mid, "inset")
    model = CreateFrame("DressUpModel", "TransmogModel", mid)
    model:SetPoint("TOPLEFT", mid, "TOPLEFT", 48, -8)
    model:SetPoint("BOTTOMRIGHT", mid, "BOTTOMRIGHT", -48, 52)
    model.rot = 0
    model:EnableMouse(true)
    model:SetScript("OnMouseDown", function() this.dragX = GetCursorPosition() end)
    model:SetScript("OnMouseUp", function() this.dragX = nil end)
    model:SetScript("OnUpdate", function()
        if this.dragX then
            local x = GetCursorPosition()
            this.rot = this.rot + (x - this.dragX) * 0.02
            this.dragX = x
            this:SetRotation(this.rot)
        end
    end)
    T.model = model
    slotButtons = {}
    local left = { 0, 2, 14, 4, 3, 18, 8 }
    local right = { 9, 5, 6, 7 }
    local bottom = { 15, 16, 17 }
    for i, slot in ipairs(left) do
        local b = makeSlot(mid, T.SLOT_BY[slot])
        b:SetPoint("TOPLEFT", mid, "TOPLEFT", 6, -10 - (i - 1) * 50)
        slotButtons[slot] = b
    end
    for i, slot in ipairs(right) do
        local b = makeSlot(mid, T.SLOT_BY[slot])
        b:SetPoint("TOPRIGHT", mid, "TOPRIGHT", -6, -10 - (i - 1) * 50)
        slotButtons[slot] = b
    end
    for i, slot in ipairs(bottom) do
        local b = makeSlot(mid, T.SLOT_BY[slot])
        b:SetPoint("BOTTOM", mid, "BOTTOM", (i - 2) * 50, 8)
        slotButtons[slot] = b
    end
    viewName = UI.Label(body, 12, UI.ACCENT)
    viewName:SetPoint("TOP", mid, "BOTTOM", 0, -6)

    -- right: tabs
    tabs = UI.Tabs(body, {
        tabs = { { key = "items", label = "Items" }, { key = "sets", label = "Sets" },
                 { key = "csets", label = "Custom Sets" }, { key = "situations", label = "Situations" } },
        onSelect = function(k) T:SelectTab(k, true) end,
    })
    tabs:SetPoint("TOPLEFT", body, "TOPLEFT", RIGHT_X, 0)
    tabs:SetWidth(RIGHT_W)
    pages = {}
    local function page(key)
        local p = CreateFrame("Frame", nil, body)
        p:SetPoint("TOPLEFT", body, "TOPLEFT", RIGHT_X, -26)
        p:SetWidth(RIGHT_W)
        p:SetHeight(440)
        p:Hide()
        pages[key] = p
        return p
    end

    -- Items
    local items = page("items")
    header = UI.Label(items, 13, UI.ACCENT)
    header:SetPoint("TOPLEFT", items, "TOPLEFT", 2, -2)
    countText2 = UI.Label(items, 10, UI.MUTED)
    countText2:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -3)
    T.countText2 = countText2
    searchBox = UI.SearchBox(items, { width = 130, placeholder = "Search", onChange = function(t)
        T.search = t
        T.page = 1
        T:RefreshGrid()
    end })
    searchBox:SetPoint("TOPRIGHT", items, "TOPRIGHT", -2, -2)
    illBtn = UI.Button(items, "Illusions", 92, 20, function()
        T.mode = (T.mode == "illusions") and "items" or "illusions"
        if T.mode == "illusions" and not T.ills then T:Send("ill") end
        T.page = 1
        T:Refresh()
    end)
    illBtn:SetPoint("RIGHT", searchBox, "LEFT", -6, 0)
    cells = {}
    for i = 1, PER_PAGE do
        local c = CreateFrame("Button", nil, items)
        c:SetWidth(CELL_W)
        c:SetHeight(CELL_H)
        local col = math.mod(i - 1, COLS)
        local row = floor((i - 1) / COLS)
        c:SetPoint("TOPLEFT", items, "TOPLEFT", col * (CELL_W + 4), -44 - row * (CELL_H + 6))
        UI.Skin(c, "inset")
        c.model = CreateFrame("DressUpModel", nil, c)
        c.model:SetPoint("TOPLEFT", c, "TOPLEFT", 3, -3)
        c.model:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", -3, 16)
        c.model:EnableMouse(false)
        c.icon = c:CreateTexture(nil, "ARTWORK")
        c.icon:SetWidth(40)
        c.icon:SetHeight(40)
        c.icon:SetPoint("CENTER", c, "CENTER", 0, 8)
        c.name = UI.Label(c, 9)
        c.name:SetPoint("BOTTOMLEFT", c, "BOTTOMLEFT", 3, 3)
        c.name:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", -3, 3)
        c.name:SetJustifyH("CENTER")
        c.sel = c:CreateTexture(nil, "OVERLAY")
        c.sel:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
        c.sel:SetBlendMode("ADD")
        c.sel:SetVertexColor(1, 0.82, 0)
        c.sel:SetPoint("TOPLEFT", c, "TOPLEFT", -14, 14)
        c.sel:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", 14, -14)
        c.lock = c:CreateTexture(nil, "OVERLAY")
        c.lock:SetTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
        c.lock:SetWidth(16)
        c.lock:SetHeight(16)
        c.lock:SetPoint("TOPRIGHT", c, "TOPRIGHT", -3, -3)
        c:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square")
        c:SetScript("OnClick", function() cellClick(this) end)
        c:SetScript("OnEnter", function() cellTip(this) end)
        c:SetScript("OnLeave", function() GameTooltip:Hide() end)
        cells[i] = c
    end
    local prev = UI.Button(items, "<", 26, 20, function() T.page = math.max(1, T.page - 1); T:RefreshGrid() end)
    prev:SetPoint("TOPLEFT", items, "TOPLEFT", 90, -44 - ROWS * (CELL_H + 6) - 4)
    pageText = UI.Label(items, 11)
    pageText:SetPoint("LEFT", prev, "RIGHT", 10, 0)
    local nextB = UI.Button(items, ">", 26, 20, function() T.page = T.page + 1; T:RefreshGrid() end)
    nextB:SetPoint("LEFT", prev, "RIGHT", 120, 0)
    T.prevBtn, T.nextBtn = prev, nextB

    -- Sets
    local sets = page("sets")
    local sh = UI.Label(sets, 11, UI.MUTED)
    sh:SetPoint("TOPLEFT", sets, "TOPLEFT", 2, -2)
    sh:SetText("Item sets your class can wear. Click one to preview it; the button beside it puts on the pieces you have collected.")
    sh:SetWidth(RIGHT_W - 4)
    sh:SetJustifyH("LEFT")
    setList = UI.ScrollList(sets, {
        width = RIGHT_W, height = 390, rowHeight = 30,
        build = function(row)
            row.name = UI.Label(row, 11)
            row.name:SetPoint("LEFT", row, "LEFT", 4, 0)
            row.have = UI.Label(row, 10, UI.MUTED)
            row.have:SetPoint("RIGHT", row, "RIGHT", -60, 0)
            row.use = UI.Button(row, "Use", 50, 20, function() if this:GetParent().item then T:UseSet(this:GetParent().item) end end)
            row.use:SetPoint("RIGHT", row, "RIGHT", -4, 0)
            row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
            row:SetScript("OnClick", function()
                local s = this.item
                if not s then return end
                local looks = {}
                for _, item in ipairs(s.items) do
                    local _, _, _, _, loc = T.ItemInfo(item)
                    local slot = slotOfEquipLoc(loc)
                    if slot then looks[slot] = { look = item, ill = 0 } end
                end
                T.preview = looks
                T:Dress(model, looks)
            end)
        end,
        update = function(row, s)
            row.name:SetText(s.name)
            row.have:SetText(s.have .. "/" .. s.total)
            if s.have > 0 then row.use:Enable() else row.use:Disable() end
        end,
    })
    setList:SetPoint("TOPLEFT", sets, "TOPLEFT", 0, -30)

    -- Custom Sets
    local cs = page("csets")
    local ch = UI.Label(cs, 11, UI.MUTED)
    ch:SetPoint("TOPLEFT", cs, "TOPLEFT", 2, -2)
    ch:SetWidth(RIGHT_W - 4)
    ch:SetJustifyH("LEFT")
    ch:SetText("Looks to keep or share: free, no outfit slot needed.")
    csetList = UI.ScrollList(cs, {
        width = RIGHT_W, height = 340, rowHeight = 24,
        build = function(row)
            row.bg = row:CreateTexture(nil, "BACKGROUND")
            row.bg:SetAllPoints(row)
            row.name = UI.Label(row, 11)
            row.name:SetPoint("LEFT", row, "LEFT", 4, 0)
            row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
            row:SetScript("OnClick", function()
                csetSel = this.item
                T.preview = T.ParseLooks(this.item.looks, "/")
                T:Refresh()
            end)
        end,
        update = function(row, s)
            row.name:SetText(s.name)
            if csetSel and csetSel.id == s.id then row.bg:SetTexture(PURPLE[1], PURPLE[2], PURPLE[3], 0.18) else row.bg:SetTexture(0, 0, 0, 0) end
        end,
    })
    csetList:SetPoint("TOPLEFT", cs, "TOPLEFT", 0, -24)
    local function selLooks() return csetSel and T.ParseLooks(csetSel.looks, "/") end
    local newB = UI.Button(cs, "Save current look", 130, 22, function()
        UI.Prompt({ title = "New custom set", default = "", maxLetters = 24, accept = "Save",
                    onAccept = function(text) T:Send("cset save 0 " .. text .. "~" .. T.FormatLooks(T:CurrentLooks(), "/")) end })
    end)
    newB:SetPoint("BOTTOMLEFT", cs, "BOTTOMLEFT", 0, 34)
    local useB = UI.Button(cs, "Use", 70, 22, function()
        local looks = selLooks()
        if not looks then return end
        for slot, l in pairs(looks) do
            if l.look <= 0 or T.known[l.look] then T.pending[slot] = { look = l.look, ill = l.ill } end
        end
        T.preview = nil
        T:SelectTab("items")
    end)
    useB:SetPoint("LEFT", newB, "RIGHT", 6, 0)
    local linkB = UI.Button(cs, "Link", 70, 22, function()
        if not csetSel then return end
        local text = T.LinkText(csetSel.name, csetSel.looks)
        if ChatFrameEditBox then
            ChatFrameEditBox:Show()
            ChatFrameEditBox:Insert(text)
        end
    end)
    linkB:SetPoint("LEFT", useB, "RIGHT", 6, 0)
    local renB = UI.Button(cs, "Rename", 70, 22, function()
        if not csetSel then return end
        local s = csetSel
        UI.Prompt({ title = "Rename custom set", default = s.name, maxLetters = 24, accept = "Rename",
                    onAccept = function(text) T:Send("cset save " .. s.id .. " " .. text .. "~" .. s.looks) end })
    end)
    renB:SetPoint("TOPLEFT", newB, "BOTTOMLEFT", 0, -6)
    local delB = UI.Button(cs, "Delete", 70, 22, function()
        if not csetSel then return end
        T:Send("cset del " .. csetSel.id)
        csetSel = nil
    end)
    delB:SetPoint("LEFT", renB, "RIGHT", 6, 0)

    -- Situations
    local si = page("situations")
    local sih = UI.Label(si, 11, UI.MUTED)
    sih:SetPoint("TOPLEFT", si, "TOPLEFT", 2, -2)
    sih:SetWidth(RIGHT_W - 4)
    sih:SetJustifyH("LEFT")
    sih:SetText("This outfit puts itself on when every category you tick here matches (any one option within a category). Free.")
    situChecks = {}
    local y = -40
    for _, cat in ipairs(SITU) do
        local l = UI.Label(si, 12, UI.ACCENT)
        l:SetPoint("TOPLEFT", si, "TOPLEFT", 2, y)
        l:SetText(cat[1])
        y = y - 18
        local colW = floor(RIGHT_W / 3)
        for i, opt in ipairs(cat[2]) do
            local cb = CreateFrame("CheckButton", nil, si, "UICheckButtonTemplate")
            cb:SetWidth(22)
            cb:SetHeight(22)
            cb:SetPoint("TOPLEFT", si, "TOPLEFT", math.mod(i - 1, 3) * colW, y - floor((i - 1) / 3) * 22)
            cb.bit = opt[1]
            local t = UI.Label(si, 10)
            t:SetPoint("LEFT", cb, "RIGHT", 0, 1)
            t:SetText(opt[2])
            cb.label = t
            tinsert(situChecks, cb)
        end
        y = y - math.ceil(getn(cat[2]) / 3) * 22 - 12
    end
    local saveSitu = UI.Button(si, "Save situations", 130, 22, function()
        if not T.view or T.view == 0 then return end
        local mask = 0
        for _, cb in ipairs(situChecks) do if cb:GetChecked() then mask = mask + cb.bit end end
        T:Send("situ " .. T.view .. " " .. mask)
    end)
    saveSitu:SetPoint("BOTTOMLEFT", si, "BOTTOMLEFT", 0, 6)

    -- bottom bar
    local bar = CreateFrame("Frame", nil, body)
    bar:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", RIGHT_X, 0)
    bar:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0)
    bar:SetHeight(28)
    applyBtn = UI.Button(bar, "Apply", 90, 22, function()
        if not T.view or T.view == 0 or not hasChanges() then return end
        T:Send("save " .. T.view .. " " .. T.FormatLooks(changes(), ","))
    end)
    applyBtn:SetPoint("RIGHT", bar, "RIGHT", 0, 0)
    resetBtn = UI.Button(bar, "Undo all", 80, 22, function() T.pending = {}; T:Refresh() end)
    resetBtn:SetPoint("RIGHT", applyBtn, "LEFT", -6, 0)
    costMoney = UI.Label(bar, 12)
    costMoney:SetPoint("RIGHT", resetBtn, "LEFT", -12, 0)
    costMoney:SetJustifyH("RIGHT")
    costNote = UI.Label(body, 10, UI.MUTED)
    costNote:SetPoint("BOTTOMLEFT", bar, "TOPLEFT", 0, 4)
    statusText = UI.Label(body, 10, UI.MUTED)
    statusText:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 0, 8)
    statusText:SetWidth(LEFT_W)
    statusText:SetJustifyH("LEFT")

    T:SelectTab("items")
    return win
end

-- -- refresh -------------------------------------------------------------------------------

function T:RefreshGrid()
    if not win then return end
    local entries = cellEntries()
    local pagesN = math.max(1, math.ceil(getn(entries) / PER_PAGE))
    if T.page > pagesN then T.page = pagesN end
    for i = 1, PER_PAGE do paintCell(cells[i], entries[(T.page - 1) * PER_PAGE + i]) end
    pageText:SetText("Page " .. T.page .. " / " .. pagesN)
    if T.page > 1 then T.prevBtn:Enable() else T.prevBtn:Disable() end
    if T.page < pagesN then T.nextBtn:Enable() else T.nextBtn:Disable() end
    local info = T.SLOT_BY[T.slot]
    if T.mode == "illusions" then
        header:SetText(info.label)
        illBtn:SetText("Appearances")
        T.countText2:SetText((T.ills and getn(T.ills) or 0) .. " illusions collected")
    else
        header:SetText(info.label)
        illBtn:SetText("Illusions")
        local n = 0
        local seen = {}
        for _, c in ipairs(T.col[T.slot] or {}) do if not seen[c.display] then seen[c.display] = true; n = n + 1 end end
        T.countText2:SetText(T.col[T.slot] and (n .. " appearances collected") or "Loading...")
    end
    if info.weapon then illBtn:Show() else illBtn:Hide() end
end

function T:Refresh()
    if not win or not win:IsShown() then return end
    if T.view == nil then T.view = (T.active and T.active > 0) and T.active or (T.unlocked > 0 and 1 or 0) end
    countText:SetText((T.unlocked or 0) .. "/" .. (T.max or 50))
    list:SetItems(outfitItems())
    for _, b in pairs(slotButtons) do paintSlot(b) end
    local o = T.outfits[T.view]
    viewName:SetText(T.view == 0 and "Equipped gear" or (o and o.name or ""))
    T:Dress(model, T.preview)
    T:RefreshGrid()
    if setList and T.sets then setList:SetItems(T.sets) end
    if csetList and T.csets then csetList:SetItems(T.csets) end
    if situChecks then
        local mask = (o and o.situ) or 0
        for _, cb in ipairs(situChecks) do
            local on = math.mod(floor(mask / cb.bit), 2) == 1
            cb:SetChecked(on)
        end
    end
    if hasChanges() then askCost() else T.cost = 0 end
    T:RefreshBottom()
    if not T.atNpc then statusText:SetText("Browsing: save changes at a Transmogrifier.")
    else statusText:SetText("") end
end

function T:Toggle(tab)
    if not T.on then T.Say("Transmog isn't on for this realm.") return end
    T:Build()
    if win:IsShown() and not tab then win:Hide() return end
    win:Show()
    if T.view == nil then T.view = (T.active and T.active > 0) and T.active or (T.unlocked > 0 and 1 or 0) end
    if not T.knownAsked then T.knownAsked = true; T:Send("known") end
    T:Send("hi")
    if T.view and T.view > 0 then T:Send("outfit " .. T.view) end
    if not T.col[T.slot] then T:Send("col " .. T.slot) end
    T:SelectTab((tab and pages[tab]) and tab or (T.tab or "items"))
end

-- the realm's answers repaint what they touch
T:Listen(function(what, a, b)
    if what == "cost" then
        if a == T.view then T.cost = b or 0 end
        T:RefreshBottom()
        return
    end
    if what == "saved" then T.pending = {} end
    if what == "active" and T.view == nil then T.view = a end
    if what == "new" and win and win:IsShown() and not T.col[T.slot] then T:Send("col " .. T.slot) end
    T:Refresh()
end)

-- Talking to a Transmogrifier opens the window instead of the gossip page.
local npcWatch = CreateFrame("Frame", "Transmog_NpcWatch")
npcWatch:RegisterEvent("GOSSIP_SHOW")
npcWatch:SetScript("OnEvent", function()
    if not T.on or not W:IsActive(T.ID) then return end
    local name = UnitName and UnitName("npc")
    if name and NPCS[name] then
        if CloseGossip then CloseGossip() end
        T:Toggle("items")
        T.atNpc = true
        T:Refresh()
    end
end)
