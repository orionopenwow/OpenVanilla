--[[
    MicroMenu.lua  (Classic+ / Open Vanilla)
    One "Classic+" button at the end of the menu bar (after Help). Click it for a small fan of the
    suite: Chronicle, Vanguard, Vault, Concord, Rally, Persona and the full AddOns window.

    Art: Interface\ClassicPlus\MicroClassicPlus[Down].blp (tools/gen_micro_button.py); falls back
    to the AddOns icon when the patch is missing. Lua 5.0 rules.
]]--

local W = WenillaCore
local UI = W.UI

-- label, icon, slash command key (SlashCmdList), argument
local ENTRIES = {
    { "Meters",    "Interface\\Icons\\Ability_Warrior_SavageBlow",        "METERS" },
    { "Threat",    "Interface\\Icons\\Ability_Warrior_DefensiveStance",   "THREAT" },
    { "Bags",      "Interface\\Icons\\INV_Misc_Bag_10",                   "BAGS" },
    { "Guilds",    "Interface\\Icons\\INV_Shirt_GuildTabard_01",          "GUILDS" },
    { "Guild Hub", "Interface\\Icons\\INV_BannerPVP_02",                  "GUILDHUB" },
    { "Dungeons",  "Interface\\Icons\\INV_Misc_Key_03",                   "DUNGEONS" },
    { "Achievements", "Interface\\Icons\\INV_Crown_01",                   "ACHIEVEMENTS" },
    { "Raid",      "Interface\\Icons\\Ability_Warrior_BattleShout",       "RALLY" },
    { "Persona",   "Interface\\Icons\\INV_Misc_Book_09",                  "PERSONA" },
    { "Quests",    "Interface\\Icons\\INV_Misc_Book_08",                  "QUESTS", "log" },
    { "Minimap ring", "Interface\\Icons\\INV_Misc_Map_01",                "QUESTS", "theme" },
    { "Move anything", "Interface\\Icons\\Ability_Rogue_Sprint",          "CPMOVE" },
    { "Workshop",   "Interface\\Icons\\INV_Misc_Note_01",                 "CPWORKSHOP" },
    { "Assistant",  "Interface\\Icons\\INV_Misc_Note_02",                 "ASSISTANT" },
    { "All AddOns", "Interface\\Icons\\INV_Misc_Gear_01",                 "CPADDONS" },
}

local btn = CreateFrame("Button", "ClassicPlusMicroButton", MainMenuBarArtFrame or UIParent)
btn:SetWidth(28)
btn:SetHeight(58)
if HelpMicroButton then
    btn:SetPoint("BOTTOMLEFT", HelpMicroButton, "BOTTOMRIGHT", -3, 0)
else
    btn:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -4, 0)
end
btn:SetFrameLevel((btn:GetParent():GetFrameLevel() or 1) + 3)

local up = btn:CreateTexture(nil, "ARTWORK")
up:SetAllPoints(btn)
local hasArt = W:Art(up, "MicroClassicPlus", nil)
if hasArt then
    btn:SetNormalTexture(up)
    local down = btn:CreateTexture(nil, "ARTWORK")
    down:SetAllPoints(btn)
    W:Art(down, "MicroClassicPlusDown", nil)
    btn:SetPushedTexture(down)
else
    -- no patch art: a plain icon in the button's face
    up:ClearAllPoints()
    up:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 2, 3)
    up:SetPoint("TOPRIGHT", btn, "BOTTOMRIGHT", -2, 27)
    up:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
    up:SetTexCoord(0.08, 0.92, 0.08, 0.92)
end
btn:SetHighlightTexture("Interface\\Buttons\\UI-MicroButton-Hilight", "ADD")

-- -- The fan ---------------------------------------------------------------------------------
local ROW = 22
local fan = CreateFrame("Frame", "ClassicPlusMicroFan", UIParent)
fan:SetWidth(150)
fan:SetHeight(table.getn(ENTRIES) * ROW + 30)
fan:SetPoint("BOTTOMRIGHT", btn, "TOPRIGHT", 4, -8)
fan:SetFrameStrata("DIALOG")
fan:SetBackdrop(UI and UI.BACKDROP or { bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, insets = { left = 4, right = 4, top = 4, bottom = 4 } })
fan:SetBackdropColor(0.07, 0.07, 0.08, 0.95)
fan:SetBackdropBorderColor(0.62, 0.62, 0.66, 1)
fan:EnableMouse(true)
fan:Hide()

local title = fan:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
title:SetPoint("TOP", fan, "TOP", 0, -8)
title:SetText("|cff00ff00Classic+|r")

local function run(e)
    local f = SlashCmdList and SlashCmdList[e[3]]
    if f then f(e[4] or "") else W.Print(e[1] .. " is not loaded.") end
end

local function addRow(e, i)
    local entry = e
    local row = CreateFrame("Button", nil, fan)
    row:SetHeight(ROW)
    row:SetPoint("TOPLEFT", fan, "TOPLEFT", 8, -22 - (i - 1) * ROW)
    row:SetPoint("TOPRIGHT", fan, "TOPRIGHT", -8, -22 - (i - 1) * ROW)
    local ic = row:CreateTexture(nil, "ARTWORK")
    ic:SetWidth(18)
    ic:SetHeight(18)
    ic:SetPoint("LEFT", row, "LEFT", 2, 0)
    ic:SetTexture(entry[2])
    ic:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    local fs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetPoint("LEFT", ic, "RIGHT", 6, 0)
    fs:SetText(entry[1])
    row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
    row:SetScript("OnClick", function()
        fan:Hide()
        run(entry)
    end)
    return row
end

for i, e in ipairs(ENTRIES) do addRow(e, i) end

-- Another addon adds its own row (once per label): W:MicroMenuAdd("Warfront", icon, "WARFRONT").
function W:MicroMenuAdd(label, icon, slashKey, arg)
    for _, e in ipairs(ENTRIES) do if e[1] == label then return end end
    local entry = { label, icon, slashKey, arg }
    table.insert(ENTRIES, entry)
    local n = table.getn(ENTRIES)
    addRow(entry, n)
    fan:SetHeight(n * ROW + 30)
end

btn:SetScript("OnClick", function()
    if fan:IsShown() then fan:Hide() else fan:Show() end
end)
btn:SetScript("OnEnter", function()
    GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
    GameTooltip:SetText("Classic+", 0, 1, 0)
    GameTooltip:AddLine("Your built-in addons: meters, threat, bags, guild finder, raid tools and roleplay profiles.", 1, 1, 1, 1)
    GameTooltip:Show()
end)
btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
if UISpecialFrames then table.insert(UISpecialFrames, "ClassicPlusMicroFan") end
