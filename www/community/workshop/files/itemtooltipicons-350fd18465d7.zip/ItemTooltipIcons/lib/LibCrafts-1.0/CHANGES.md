### Revision 14 (2025/12/21)
- Turtle: Update localization

### Revision 14 (2025/09/09)
- Turtle: Add a lot of missing recipes
- Fix a bunch of data errors
- Add craft spell id to craft objects
- Fix debug mode

### Revision 13 (2025/09/05)
- Turtle: Add new 1.18 alchemy concoction recipes
- Turtle: Add localization updates from patch 1.18.7230

### Revision 13 (2025/08/17)
- Turtle: Support the latest localization updates (including deDE game client)

### Revision 12 (2025/08/16)
- Turtle: Fix Jewelcrafting database errors
- Turtle: Add some missing 1.17.2 recipes
- Turtle: Add some 1.18.0 recipe changes
- Turtle: Support Disguise profession

### Revision 11 (2025/06/11)
- Fix a lot of database errors

### Revision 10 (2025/06/10)
- Fix localized profession names

### Revision 9 (2025/06/10)
- Vanilla: Fix a bunch of localization mistakes
- Turtle: Fully support esES, ptBR and zhCN locales
- Turtle: Add several missing crafts
- Turtle: Fix and rework Jewelcrafting

### Revision 8 (2025/06/07)
- Attempt to work around a supposed bug in SpellInfo SuperWoW function

### Revision 7 (2025/06/04)
- Significantly improve localization support by using SuperWoW (if available)

### Revision 6 (2025/06/01)
- Add a couple of missing Turtle-specific recipes
- Add GetCraftsByRecipeId to public API

### Revision 5 (2025/05/03)
- Support Turtle WoW Jewelcrafting profession (by [KasVital](https://github.com/KasVital))

### Revision 4 (2024/11/09)
- Add locale modules for profession names
- Add GetCraftsByProfession() API
- Fix First Aid profession name
- Fix library in-memory upgrade process

### Revision 3 (2024/11/03)
- Add new Turtle WoW recipes for Vanilla professions
- Fix craft indentation
- Update some translations

### Revision 2 (2024/11/02)
- Disable debug mode

### Revision 1 (2024/11/02)
- Release the first version
