### v1.4.1 (2025/12/21)
- Update LibCrafts (support latest Turtle localization changes)

### v1.4 (2025/09/09)
- Update LibCrafts (add a lot of Turtle recipes, fix data errors)
- Add very basic support of craft tooltips

### v1.3.3 (2025/09/05)
- Update LibCrafts and LibCraftingProfessions (support latest Turtle localization changes, add new alchemy recipes)

### v1.3.2 (2025/08/17)
- Update LibCrafts and LibCraftingProfessions (support latest Turtle localization changes including deDE game client)

### v1.3.1 (2025/08/16)
- Update LibCrafts and LibCraftingProfessions

### v1.3 (2025/08/01)
- Support pfUI

### v1.2.2 (2025/08/01)
- Fix random Ace3 layout-related crashes

### v1.2.1 (2025/07/18)
- Update color scheme to use softer, more readable colors

### v1.2 (2025/06/23)
- Fix broken TradeSkillFrame filters

### v1.1 (2025/06/20)
- Add search field to the UI

### v1.0 (2025/06/17)
- Initial release
